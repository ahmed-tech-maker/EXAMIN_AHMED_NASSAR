/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author ahmed
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class GUARDAR {
       private ArrayList<Modelo> mecanicos;

    public GUARDAR(ArrayList<Modelo> mecanicos) {
        this.mecanicos = mecanicos;
}

    public void mostrarInterfaz() {
        JFrame frame = new JFrame("Guardar Mecánico");
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setSize(400, 400);

        JLabel labelIdMecanico = new JLabel("ID Mecánico:");
        JTextField textFieldIdMecanico = new JTextField();

        JLabel labelNombre = new JLabel("Nombre:");
        JTextField textFieldNombre = new JTextField();

        JLabel labelEdad = new JLabel("Edad:");
        JTextField textFieldEdad = new JTextField();

        JLabel labelDomicilio = new JLabel("Domicilio:");
        JTextField textFieldDomicilio = new JTextField();

        JLabel labelTitulo = new JLabel("Título:");
        JTextField textFieldTitulo = new JTextField();

        JLabel labelEspecialidad = new JLabel("Especialidad:");
        JTextField textFieldEspecialidad = new JTextField();

        JLabel labelSueldoBase = new JLabel("Sueldo Base:");
        JTextField textFieldSueldoBase = new JTextField();

        JLabel labelGratTitulo = new JLabel("Gratificación Título:");
        JTextField textFieldGratTitulo = new JTextField();

        JButton guardarButton = new JButton("Guardar");
        guardarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    int idMecanico = Integer.parseInt(textFieldIdMecanico.getText());
                    String nombre = textFieldNombre.getText();
                    int edad = Integer.parseInt(textFieldEdad.getText());
                    String domicilio = textFieldDomicilio.getText();
                    String titulo = textFieldTitulo.getText();
                    String especialidad = textFieldEspecialidad.getText();
                    double sueldoBase = Double.parseDouble(textFieldSueldoBase.getText());
                    double gratTitulo = Double.parseDouble(textFieldGratTitulo.getText());

                    Modelo nuevoMecanico = new Modelo(idMecanico, nombre, edad, domicilio, titulo, especialidad, sueldoBase, gratTitulo);
                    mecanicos.add(nuevoMecanico);

                    JOptionPane.showMessageDialog(null, "Mecánico guardado exitosamente");
                    frame.dispose();
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "Ingrese datos válidos");
                }
            }
        });

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(10, 2));
        panel.add(labelIdMecanico);
        panel.add(textFieldIdMecanico);
        panel.add(labelNombre);
        panel.add(textFieldNombre);
        panel.add(labelEdad);
        panel.add(textFieldEdad);
        panel.add(labelDomicilio);
        panel.add(textFieldDomicilio);
        panel.add(labelTitulo);
        panel.add(textFieldTitulo);
        panel.add(labelEspecialidad);
        panel.add(textFieldEspecialidad);
        panel.add(labelSueldoBase);
        panel.add(textFieldSueldoBase);
        panel.add(labelGratTitulo);
        panel.add(textFieldGratTitulo);
        panel.add(guardarButton);

        frame.add(panel);
        frame.setVisible(true);
    }
}