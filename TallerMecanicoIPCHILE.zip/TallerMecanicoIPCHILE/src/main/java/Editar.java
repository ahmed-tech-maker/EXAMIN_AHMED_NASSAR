/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author ahmed
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class Editar {
     private ArrayList<Modelo> mecanicos;

    public Editar(ArrayList<Modelo> mecanicos) {
        this.mecanicos = mecanicos;
}

    // Método principal para mostrar la interfaz de edición
    public void mostrarInterfaz() {
        JFrame frame = new JFrame("Editar Mecánico");
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setSize(400, 400);

        // Crear componentes de la interfaz de búsqueda
        JLabel labelIdMecanico = new JLabel("ID Mecánico:");
        JTextField textFieldIdMecanico = new JTextField();
        JButton buscarButton = new JButton("Buscar");

        // Acción del botón de búsqueda
        buscarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    // Obtener el ID ingresado
                    int idMecanico = Integer.parseInt(textFieldIdMecanico.getText());
                    // Buscar el mecánico en el arreglo
                    Modelo mec = buscarMecanico(idMecanico);

                    if (mec != null) {
                        // Llamada a la interfaz de edición con el mecánico encontrado
                        mostrarInterfazEdicion(mec);
                    } else {
                        JOptionPane.showMessageDialog(null, "Mecánico no encontrado");
                    }
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "Ingrese un ID Mecánico válido");
                }
            }
        });

        // Panel para la interfaz de búsqueda
        JPanel panelBuscar = new JPanel();
        panelBuscar.setLayout(new GridLayout(1, 3));
        panelBuscar.add(labelIdMecanico);
        panelBuscar.add(textFieldIdMecanico);
        panelBuscar.add(buscarButton);

        // Agregar el panel de búsqueda al frame
        frame.add(panelBuscar);
        frame.setVisible(true);
    }

    // Método para buscar un mecánico por su ID
    private Modelo buscarMecanico(int idMecanico) {
        for (Modelo mec : mecanicos) {
            if (mec.getidMecanico() == idMecanico) {
                return mec;
            }
        }
        return null;
    }

    // Método para mostrar la interfaz de edición con los datos del mecánico
    private void mostrarInterfazEdicion(Modelo mec) {
        JFrame frame = new JFrame("Editar Mecánico");
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setSize(400, 400);

        // Crear componentes de la interfaz de edición
        JLabel labelIdMecanico = new JLabel("ID Mecánico:");
        JTextField textFieldIdMecanico = new JTextField(String.valueOf(mec.getIdMecanico()));
        textFieldIdMecanico.setEditable(false);

        JLabel labelNombre = new JLabel("Nombre:");
        JTextField textFieldNombre = new JTextField(mec.getNombre());

        JLabel labelEdad = new JLabel("Edad:");
        JTextField textFieldEdad = new JTextField(String.valueOf(mec.getEdad()));

        // Repite para los demás campos...

        JButton guardarCambiosButton = new JButton("Guardar Cambios");

        // Acción del botón de guardar cambios
        guardarCambiosButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Actualizar los datos del mecánico con los valores ingresados
                mec.setNombre(textFieldNombre.getText());
                mec.setEdad(Integer.parseInt(textFieldEdad.getText()));
                // Repite para los demás campos...

                JOptionPane.showMessageDialog(null, "Cambios guardados exitosamente");
                frame.dispose(); // Cerrar la interfaz de edición
            }
        });

        // Panel para la interfaz de edición
        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(10, 2));
        panel.add(labelIdMecanico);
        panel.add(textFieldIdMecanico);
        panel.add(labelNombre);
        panel.add(textFieldNombre);
        panel.add(labelEdad);
        panel.add(textFieldEdad);
        // Repite para los demás campos...
        panel.add(guardarCambiosButton);

        // Agregar el panel de edición al frame
        frame.add(panel);
        frame.setVisible(true);
    }
}