/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author ahmed
 */
import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import javax.swing.table.DefaultTableModel;

public class Listar {
    private ArrayList<Modelo> mecanicos;

    public Listar(ArrayList<Modelo> mecanicos) {
        this.mecanicos = mecanicos;
}
 // Método para mostrar la interfaz de listado
    public void mostrarInterfaz() {
        JFrame frame = new JFrame("Listar Mecánicos");
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setSize(600, 400);

        // Crear un modelo de tabla para mostrar los datos
        DefaultTableModel tableModel = new DefaultTableModel();
        JTable table = new JTable(tableModel);

        // Agregar columnas a la tabla
        tableModel.addColumn("ID Mecánico");
        tableModel.addColumn("Nombre");
        tableModel.addColumn("Edad");
        tableModel.addColumn("Domicilio");
        tableModel.addColumn("Título");
        tableModel.addColumn("Especialidad");
        tableModel.addColumn("Sueldo Base");
        tableModel.addColumn("Gratificación Título");
        tableModel.addColumn("Sueldo Total");

        // Llenar la tabla con los datos de los mecánicos
        for (Modelo mec : mecanicos) {
            Object[] rowData = {
                    mec.getIdMecanico(),
                    mec.getNombre(),
                    mec.getEdad(),
                    mec.getDomicilio(),
                    mec.getTitulo(),
                    mec.getEspecialidad(),
                    mec.getSueldoBase(),
                    mec.getGratTitulo(),
                    mec.getSueldoTotal()
            };
            tableModel.addRow(rowData);
        }

        // Agregar la tabla a un JScrollPane para permitir el desplazamiento
        JScrollPane scrollPane = new JScrollPane(table);

        // Agregar el JScrollPane al frame
        frame.add(scrollPane);

        // Mostrar el frame
        frame.setVisible(true);
    }
}