/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author ahmed
 */
import java.util.ArrayList;
class Modelo {
 private int idMecanico;
    private String nombre;
    private int edad;
    private String domicilio;
    private String titulo;
    private String especialidad;
    private double sueldoBase;
    private double gratTitulo;
    private double sueldoTotal;

    public Modelo(int idMecanico, String nombre, int edad, String domicilio, String titulo,
                  String especialidad, double sueldoBase, double gratTitulo) {
        this.idMecanico = idMecanico;
        this.nombre = nombre;
        this.edad = edad;
        this.domicilio = domicilio;
        this.titulo = titulo;
        this.especialidad = especialidad;
        this.sueldoBase = sueldoBase;
        this.gratTitulo = gratTitulo;

        // Realizar la operación "trabajado" al crear el objeto
        calcularSueldoTotal();
    
}
 // Método para realizar la operación "trabajado"
    private void calcularSueldoTotal() {
        sueldoTotal = sueldoBase + gratTitulo;
    }

    // Otros métodos getter y setter según sea necesario
    // ...

    // Método para obtener los datos ya "trabajados"
    public Object[] obtenerDatosTrabajados() {
        return new Object[]{idMecanico, nombre, edad, domicilio, titulo, especialidad, sueldoBase, gratTitulo, sueldoTotal};
    }

    Object getIdMecanico() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    String getNombre() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    Object getEdad() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    void setNombre(String text) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    void setEdad(int parseInt) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    Object getDomicilio() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    Object getTitulo() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    Object getSueldoBase() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    Object getEspecialidad() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    Object getGratTitulo() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    Object getSueldoTotal() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    int getidMecanico() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

}