/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.tallermecanicoipchile;

/**
 *
 * @author ahmed
 */

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
public class TallerMecanicoIPCHILE {

    public static void main(String[] args) {
         
       
         SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("Taller Mecánico IPCHILE");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setSize(400, 300);

            JButton crearNuevoMecanicoButton = new JButton("Crear Nuevo Mecánico");
            JButton editarNuevoMecanicoButton = new JButton("Editar Nuevo Mecánico");
            JButton listarTodosLosMecanicosButton = new JButton("Listar Todos los Mecánicos");
            JButton eliminarUnMecanicoButton = new JButton("Eliminar un Mecánico");

            crearNuevoMecanicoButton.addActionListener(e -> {
                // Lógica para abrir la interfaz de crear nuevo mecánico
                CrearNuevoMecanico interfazCrear = new CrearNuevoMecanico();
                interfazCrear.mostrarInterfaz();
            });

            editarNuevoMecanicoButton.addActionListener(e -> {
                // Lógica para abrir la interfaz de editar nuevo mecánico
                EditarNuevoMecanico interfazEditar = new EditarNuevoMecanico();
                interfazEditar.mostrarInterfaz();
            });

            listarTodosLosMecanicosButton.addActionListener(e -> {
                // Lógica para abrir la interfaz de listar todos los mecánicos
                ListarTodosLosMecanicos interfazListar = new ListarTodosLosMecanicos();
                interfazListar.mostrarInterfaz();
            });

            eliminarUnMecanicoButton.addActionListener(e -> {
                // Lógica para abrir la interfaz de eliminar un mecánico
                EliminarUnMecanico interfazEliminar = new EliminarUnMecanico();
                interfazEliminar.mostrarInterfaz();
            });

            JPanel panel = new JPanel();
            panel.setLayout(new GridLayout(4, 1));
            panel.add(crearNuevoMecanicoButton);
            panel.add(editarNuevoMecanicoButton);
            panel.add(listarTodosLosMecanicosButton);
            panel.add(eliminarUnMecanicoButton);

            frame.add(panel);
            frame.setVisible(true);
        });
    }
}

// Clases para las operaciones correspondientes...

class CrearNuevoMecanico {
    public void mostrarInterfaz() {
        // Lógica para la interfaz de crear nuevo mecánico
        // Puedes usar JOptionPane o JFrame según tus necesidades
        JOptionPane.showMessageDialog(null, "Interfaz para Crear Nuevo Mecánico");
    }
}

class EditarNuevoMecanico {
    public void mostrarInterfaz() {
        // Lógica para la interfaz de editar nuevo mecánico
        JOptionPane.showMessageDialog(null, "Interfaz para Editar Nuevo Mecánico");
    }
}

class ListarTodosLosMecanicos {
    public void mostrarInterfaz() {
        // Lógica para la interfaz de listar todos los mecánicos
        JOptionPane.showMessageDialog(null, "Interfaz para Listar Todos los Mecánicos");
    }
}

class EliminarUnMecanico {
    public void mostrarInterfaz() {
        // Lógica para la interfaz de eliminar un mecánico
        JOptionPane.showMessageDialog(null, "Interfaz para Eliminar un Mecánico");
    }

    }

