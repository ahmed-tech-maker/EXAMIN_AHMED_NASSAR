/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author ahmed
 */
import java.awt.GridLayout;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class Eliminar {
     private ArrayList<Modelo> mecanicos;

    public Eliminar(ArrayList<Modelo> mecanicos) {
        this.mecanicos = mecanicos;
}
// Método para mostrar la interfaz de eliminación
    public void mostrarInterfaz() {
        JFrame frame = new JFrame("Eliminar Mecánico");
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setSize(400, 200);

        // Crear componentes de la interfaz de eliminación
        JLabel labelIdMecanico = new JLabel("ID Mecánico:");
        JTextField textFieldIdMecanico = new JTextField();
        JButton eliminarButton = new JButton("Eliminar");

        // Acción del botón de eliminación
        eliminarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    // Obtener el ID ingresado
                    int idMecanico = Integer.parseInt(textFieldIdMecanico.getText());

                    // Llamar al método para eliminar el mecánico
                    boolean eliminado = eliminarMecanico(idMecanico);

                    if (eliminado) {
                        JOptionPane.showMessageDialog(null, "Mecánico eliminado exitosamente");
                    } else {
                        JOptionPane.showMessageDialog(null, "Mecánico no encontrado");
                    }
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "Ingrese un ID Mecánico válido");
                }
            }
        });

        // Crear un panel para la interfaz de eliminación
        JPanel panelEliminar = new JPanel();
        panelEliminar.setLayout(new GridLayout(2, 2));
        panelEliminar.add(labelIdMecanico);
        panelEliminar.add(textFieldIdMecanico);
        panelEliminar.add(eliminarButton);

        // Agregar el panel al frame
        frame.add(panelEliminar);
        frame.setVisible(true);
    }

    // Método para eliminar un mecánico del arreglo
    private boolean eliminarMecanico(int idMecanico) {
        for (var mec : mecanicos) {
            if (mec.getidMecanico() == idMecanico) {
                mecanicos.remove(mec);
                return true; // Mecánico encontrado y eliminado
            }
        }
        return false; // Mecánico no encontrado
    }
}